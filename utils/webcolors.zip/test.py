from webcolors import hex_to_rgb as c

colors = [
	"#3f51b5",
	"#9e9e9e",
	"#8bc34a",
	"#2196f3",
	"#000000",
	"#cddc39",
	"#4caf50",
	"#009688",
	"#ffeb3b",
	"#673ab7",
	"#e91e63",
	"#ff9800",
	"#f44336",
	"#ffffff",
	"#607d8b",
	"#9c27b0",
	"#ffc107",
	"#00bcd4",
	"#ff5722",
	"#03a9f4",
	"#795548"
]

for color in colors:
	rgba = "rgba{0}".format(c(color))
	rgba = rgba.replace(")", ", @o)")
	print("._{0}{{background-color:{1};border:1px solid {1}}}".format(color[1:], rgba))
