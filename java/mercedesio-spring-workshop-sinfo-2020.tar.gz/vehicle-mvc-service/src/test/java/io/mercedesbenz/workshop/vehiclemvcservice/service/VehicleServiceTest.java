package io.mercedesbenz.workshop.vehiclemvcservice.service;

import static io.mercedesbenz.workshop.vehiclemvcservice.Utils.buildVehicle;
import static io.mercedesbenz.workshop.vehiclemvcservice.Utils.buildVehicleDto;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import io.mercedesbenz.workshop.vehiclemvcservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclemvcservice.repository.VehicleRepository;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.exception.VehicleNotFoundException;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class VehicleServiceTest {

  @Mock private VehicleRepository vehicleRepository;

  @InjectMocks private VehicleService vehicleService;

  @Test
  void findByVin_should_return_vehicle_when_vehicle_exists() throws Exception {
    // given
    final String vin = "4JGBF7BE5BA672170";
    final Vehicle vehicle = buildVehicle(vin);
    final VehicleDto vehicleDto = buildVehicleDto(vin);

    // when
    when(vehicleRepository.findById(vin)).thenReturn(Optional.of(vehicle));

    // then
    VehicleDto returnedVehicle = vehicleService.findByVin(vin);

    assertThat(vehicleDto, is(equalTo(returnedVehicle)));

    verify(vehicleRepository, times(1)).findById(vin);
    verifyNoMoreInteractions(vehicleRepository);
  }

  @Test
  void findByVin_should_throw_when_vehicle_does_not_exist() {
    // given
    final String vin = "4JGBF7BE5BA672170";

    // when
    when(vehicleRepository.findById(vin)).thenReturn(Optional.empty());

    // then
    assertThrows(VehicleNotFoundException.class, () -> vehicleService.findByVin(vin));

    verify(vehicleRepository, times(1)).findById(vin);
    verifyNoMoreInteractions(vehicleRepository);
  }

  @Test
  void findAll_should_return_a_collection_of_vehicles() {
    // given
    final String vin = "4JGBF7BE5BA672170";

    final Vehicle vehicle = buildVehicle(vin);
    final List<Vehicle> vehiclesInDatabase = List.of(vehicle);

    final VehicleDto vehicleDto = buildVehicleDto(vin);
    final List<VehicleDto> vehiclesToReturn = List.of(vehicleDto);

    // when
    when(vehicleRepository.findAll()).thenReturn(vehiclesInDatabase);

    // then
    Collection<VehicleDto> vehiclesReturned = vehicleService.findAll();

    assertThat(vehiclesToReturn, is(equalTo(vehiclesReturned)));

    verify(vehicleRepository, times(1)).findAll();
    verifyNoMoreInteractions(vehicleRepository);
  }
}
