package io.mercedesbenz.workshop.vehiclemvcservice.controller;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.mercedesbenz.workshop.vehiclemvcservice.Utils;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.exception.ControllerExceptionHandler;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.exception.VehicleNotFoundException;
import io.mercedesbenz.workshop.vehiclemvcservice.service.VehicleService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(SpringExtension.class)
class VehicleControllerTest {

  @Mock private VehicleService vehicleService;

  @InjectMocks private VehicleController vehicleController;

  private ObjectMapper json;

  private MockMvc mockMvc;

  @BeforeEach
  public void setUp() {
    json = new ObjectMapper();
    mockMvc =
        MockMvcBuilders.standaloneSetup(vehicleController)
            .setControllerAdvice(new ControllerExceptionHandler())
            .build();
  }

  @Test
  void findByVin_should_return_vehicle_and_200_ok_when_vehicle_with_vin_exists() throws Exception {
    // given
    final String vin = "4JGBF7BE5BA672170";
    VehicleDto vehicle = Utils.buildVehicleDto(vin);

    // when
    when(vehicleService.findByVin(vin)).thenReturn(vehicle);

    // then
    MvcResult response =
        mockMvc
            .perform(get("{BASE_URL}/{VIN}", VehicleController.BASE_URL, vin))
            .andExpect(status().isOk())
            .andReturn();

    String responseBody = response.getResponse().getContentAsString();
    VehicleDto responseVehicle = json.readValue(responseBody, VehicleDto.class);

    assertThat(responseVehicle, is(equalTo(vehicle)));
    verify(vehicleService, times(1)).findByVin(vin);
    verifyNoMoreInteractions(vehicleService);
  }

  @Test
  void findByVin_should_return_404_not_found_when_vehicle_with_vin_does_not_exist()
      throws Exception {
    // given
    final String vin = "4JGBF7BE5BA672170";

    // when
    when(vehicleService.findByVin(vin)).thenThrow(VehicleNotFoundException.class);

    // then
    mockMvc
        .perform(get("{BASE_URL}/{VIN}", VehicleController.BASE_URL, vin))
        .andExpect(status().isNotFound());

    verify(vehicleService, times(1)).findByVin(vin);
    verifyNoMoreInteractions(vehicleService);
  }

  @Test
  void findAll_should_return_all_available_vehicles_and_200_ok() throws Exception {
    // given
    final String vin = "4JGBF7BE5BA672170";
    final List<VehicleDto> vehicles = List.of(Utils.buildVehicleDto(vin));

    // when
    when(vehicleService.findAll()).thenReturn(vehicles);

    // then
    MvcResult response =
        mockMvc
            .perform(get(VehicleController.BASE_URL))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andReturn();

    String responseBody = response.getResponse().getContentAsString();
    List responseVehicles = json.readValue(responseBody, List.class);

    assertThat(responseVehicles.size(), is(equalTo(vehicles.size())));

    verify(vehicleService, times(1)).findAll();
    verifyNoMoreInteractions(vehicleService);
  }
}
