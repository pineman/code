package io.mercedesbenz.workshop.vehiclemvcservice;

import io.mercedesbenz.workshop.vehiclemvcservice.model.FuelType;
import io.mercedesbenz.workshop.vehiclemvcservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;

public class Utils {

  public static Vehicle buildVehicle(String vin) {
    return Vehicle.builder().vin(vin).brand("MB").model("C250").fuelType("DIESEL").build();
  }

  public static VehicleDto buildVehicleDto(String vin) {
    return VehicleDto.builder()
        .vin(vin)
        .brand("MB")
        .model("C250")
        .fuelType(FuelType.DIESEL)
        .build();
  }
}
