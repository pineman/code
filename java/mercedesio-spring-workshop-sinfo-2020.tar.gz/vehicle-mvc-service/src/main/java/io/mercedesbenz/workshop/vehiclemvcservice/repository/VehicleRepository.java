package io.mercedesbenz.workshop.vehiclemvcservice.repository;

import io.mercedesbenz.workshop.vehiclemvcservice.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleRepository extends JpaRepository<Vehicle, String> {}
