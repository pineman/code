package io.mercedesbenz.workshop.vehiclemvcservice.model;

public enum FuelType {
  DIESEL,
  GASOLINE,
  ELECTRIC,
  HYBRID
}
