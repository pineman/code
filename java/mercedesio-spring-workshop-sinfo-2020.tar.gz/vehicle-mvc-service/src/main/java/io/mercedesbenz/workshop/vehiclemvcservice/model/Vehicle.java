package io.mercedesbenz.workshop.vehiclemvcservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vehicle {

  @Id
  @Column(unique = true)
  private String vin;

  private String brand;

  private String model;

  private String fuelType;

  private int kw;
}
