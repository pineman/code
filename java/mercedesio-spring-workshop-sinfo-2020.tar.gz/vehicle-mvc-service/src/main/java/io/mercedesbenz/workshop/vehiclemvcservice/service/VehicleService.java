package io.mercedesbenz.workshop.vehiclemvcservice.service;

import io.mercedesbenz.workshop.vehiclemvcservice.repository.VehicleRepository;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.exception.VehicleNotFoundException;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.mapper.VehicleMapper;
import java.util.Collection;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {

  private final VehicleRepository vehicleRepository;

  @Autowired
  public VehicleService(VehicleRepository vehicleRepository) {
    this.vehicleRepository = vehicleRepository;
  }

  public Collection<VehicleDto> findAll() {
    return vehicleRepository.findAll().stream()
        .map(VehicleMapper.INSTANCE::map)
        .collect(Collectors.toList());
  }

  public VehicleDto findByVin(String vin) {
    return vehicleRepository
        .findById(vin)
        .map(VehicleMapper.INSTANCE::map)
        .orElseThrow(() -> new VehicleNotFoundException(vin));
  }

  public void save(VehicleDto vehicleDto){
    vehicleRepository.save(VehicleMapper.INSTANCE.map(vehicleDto));
  }
}
