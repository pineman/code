package io.mercedesbenz.workshop.vehiclemvcservice.resource.mapper;

import io.mercedesbenz.workshop.vehiclemvcservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface VehicleMapper {

  VehicleMapper INSTANCE = Mappers.getMapper(VehicleMapper.class);

  VehicleDto map(Vehicle vehicleDto);

  Vehicle map(VehicleDto vehicleDto);
}
