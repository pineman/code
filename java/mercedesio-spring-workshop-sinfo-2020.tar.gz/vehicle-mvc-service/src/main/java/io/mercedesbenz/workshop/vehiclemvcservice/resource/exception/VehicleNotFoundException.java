package io.mercedesbenz.workshop.vehiclemvcservice.resource.exception;

public class VehicleNotFoundException extends RuntimeException {

  public VehicleNotFoundException(String vin) {
    super(String.format("Vehicle with vin \"%s\" could not be found.", vin));
  }
}
