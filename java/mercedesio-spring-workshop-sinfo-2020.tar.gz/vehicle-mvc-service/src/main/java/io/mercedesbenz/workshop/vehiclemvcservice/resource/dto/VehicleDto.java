package io.mercedesbenz.workshop.vehiclemvcservice.resource.dto;

import io.mercedesbenz.workshop.vehiclemvcservice.model.FuelType;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDto implements Serializable {

  @NotBlank(message = "Vin is required")
  private String vin;

  private String brand;

  private String model;

  private FuelType fuelType;

  private int kw;
}
