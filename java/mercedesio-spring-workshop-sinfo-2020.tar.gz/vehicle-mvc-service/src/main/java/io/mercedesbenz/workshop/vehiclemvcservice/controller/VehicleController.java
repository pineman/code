package io.mercedesbenz.workshop.vehiclemvcservice.controller;

import io.mercedesbenz.workshop.vehiclemvcservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclemvcservice.service.VehicleService;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(VehicleController.BASE_URL)
public class VehicleController {

  private final VehicleService vehicleService;
  public static final String BASE_URL = "/vehicles";

  @Autowired
  public VehicleController(VehicleService vehicleService) {
    this.vehicleService = vehicleService;
  }

  @GetMapping("/{vin}")
  public VehicleDto findByVin(@PathVariable("vin") String vin) {
    log.info("Fetching vehicle with vin: {}", vin);

    VehicleDto vehicle = vehicleService.findByVin(vin);

    log.info("Found vehicle: {}", vehicle);

    return vehicle;
  }

  @GetMapping
  public Collection<VehicleDto> findAll() {
    log.info("Fetching all vehicles");

    Collection<VehicleDto> vehicles = vehicleService.findAll();

    log.info("Returned all vehicles");

    return vehicles;
  }

  @PostMapping
  @ResponseStatus(HttpStatus.CREATED)
  public void create(@RequestBody VehicleDto vehicleDto) {
    log.info("Creating vehicle with vin {}", vehicleDto.getVin());

    vehicleService.save(vehicleDto);

    log.info("Vehicle with vin {} created", vehicleDto.getVin());
  }

}
