# SINFO 2020 Workshop

## Spring MVC

A Spring MVC project example.
