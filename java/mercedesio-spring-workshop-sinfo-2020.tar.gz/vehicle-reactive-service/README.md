# SINFO workshop - Reactive Webservices

The use case is to create a WebFlux microservice to perform write/read operations on vehicles in the database.
We provide you with a complete implementation of WebMVC microservice and your task is to replicate the same features using WebFlux.
We've written tests that will help you on what you need to implement to make them pass successfully and therefore accomplish the correct implementation of a reactive pogramming version of this use case.

----------

## Setup environment
- Install git
- Install JDK 11
- Install Intellij
    - Install lombok plugin
- Install Docker
- Clone git repositories
```bash
git clone https://github.com/mercedesbenzio/admin-server.git
git clone https://github.com/mercedesbenzio/vehicle-mvc-service.git
git clone https://github.com/mercedesbenzio/vehicle-reactive-service.git
```

> For `vehicle-reactive-service` the compiler fails due to the missing implementation. Don't worry, you will create the implementation to fix this!

## Checkpoint 1 – Implement find all vehicles feature
Find all the vehicles in the database and return them.
> Steps:
> - Call a repository method that will return all the vehicles
> - Map the returned object from the repository to the respective object that the service must return
> - The response should handle 0 to N elements
> - In the controller, log a successful message when all vehicles have been returned
> - Run unit tests

After the resolution you'll stash your changes:
```sh
git stash save "My checkpoint1"
```
Checkout the next check point:
```bash
git fetch && git checkout checkpoint2
```

## Checkpoint 2 – Implement find a vehicle by VIN feature
Find a specific vehicle by a VIN (Vehicle Identification Number) in the database. If found, return it, otherwise return an error.
> Steps:
> - Call a repository method that will return all a vehicles by an identifier
> - Map the returned object from the repository to the respective object that the service must return
> - The response should handle 0 to 1 element
> - When the response from the repository is empty, return an exception
> - In the controller, log a successful message when the vehicle is found
> - Run unit tests

After the resolution you'll stash your changes:
```sh
git stash save "My checkpoint2"
```
Checkout the next check point:
```bash
git fetch && git checkout checkpoint3
```

## Checkpoint 3 – Implement create a vehicle feature
Create a vehicle and save it in the database.
> Steps:
> - Call a repository method that will save one vehicle
> - Map the given vehicle dto to the equivalent database object
> - In the controller, log a successful message when the vehicle is created
> - Run unit tests

After the resolution you'll stash your changes:
```sh
git stash save "My checkpoint3"
```
Checkout the next check point:
```bash
git fetch && git checkout final-solution
```
___

#### If all the checkpoints are successfully implemented, start the database and run the integration tests.

##### Set up databases
We will use docker for this demonstration.

Run the following command in the root path of the project:
```bash
docker-compose up
```
##### Run integration tests
```sh
./mvnw clean verify -Pintegration
```

## Run Admin server, webmvc and webflux microservices
Run Admin server for analysis:
```sh
./mvnw clean install spring-boot:run
```
And then open http://localhost:8080

Run both projects and check their status using the following URLs (don't forget to start the databse for vehicles-mvc-service using docker):

#### vehicle-reactive-service
```sh
./mvnw spring-boot:run
```

http://localhost:8081/actuator/info
http://localhost:8081/actuator/health
#### vehicle-mvc-service
```sh
./mvnw spring-boot:run
```
http://localhost:8082/actuator/info
http://localhost:8082/actuator/health

## Test performance
Play around with the services. 
We use apachebench to compare the results between the services, but feel free a tool of your choice.
> Use `ab --help` to check the options
> Open admin server console for more details

Requests examples:
##### find a vehicle 
###### webflux
```sh
ab -v 1 -r -s 2000 -n 1000 -c 100 http://localhost:8081/vehicles/WDD1000000000000001
```
###### webmvc
```sh
ab -v 1 -r -s 2000 -n 1000 -c 100 http://localhost:8082/vehicles/WDD1000000000000001
```
##### find all vehicles
###### webflux
```sh
ab -v 1 -r -s 2000 -n 100 -c 100 http://localhost:8081/vehicles
```
###### webmvc
```sh
ab -v 1 -r -s 2000 -n 100 -c 100 http://localhost:8082/vehicles
```
