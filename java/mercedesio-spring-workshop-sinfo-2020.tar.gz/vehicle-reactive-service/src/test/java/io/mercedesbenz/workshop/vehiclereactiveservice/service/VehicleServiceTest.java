package io.mercedesbenz.workshop.vehiclereactiveservice.service;

import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_1;
import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_2;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import io.mercedesbenz.workshop.vehiclereactiveservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclereactiveservice.repository.VehicleRepository;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.exception.VehicleNotFoundException;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class VehicleServiceTest {

  private VehicleService vehicleService;

  @Mock private VehicleRepository vehicleRepository;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    vehicleService = new VehicleService(vehicleRepository);
  }

  @Test
  void findByVin_vinExists_success() {
    VehicleDto vehicleDto = VehicleDto.builder().vin(VIN_1).build();
    Vehicle vehicle = Vehicle.builder().vin(VIN_1).build();
    when(vehicleRepository.findById(VIN_1)).thenReturn(Mono.just(vehicle));

    StepVerifier.create(vehicleService.findByVin(VIN_1))
        .assertNext(result -> assertEquals(result, vehicleDto))
        .verifyComplete();

    verify(vehicleRepository).findById(VIN_1);
    verifyNoMoreInteractions(vehicleRepository);
  }

  @Test
  void findByVin_vinNotFound_error() {
    when(vehicleRepository.findById(VIN_1)).thenReturn(Mono.empty());

    StepVerifier.create(vehicleService.findByVin(VIN_1))
        .verifyError(VehicleNotFoundException.class);

    verify(vehicleRepository).findById(VIN_1);
    verifyNoMoreInteractions(vehicleRepository);
  }

  @Test
  void findAll() {
    VehicleDto vehicleDto = VehicleDto.builder().vin(VIN_1).build();
    VehicleDto vehicleDto2 = VehicleDto.builder().vin(VIN_2).build();
    Vehicle vehicle = Vehicle.builder().vin(VIN_1).build();
    Vehicle vehicle2 = Vehicle.builder().vin(VIN_2).build();
    Flux<Vehicle> vehicles = Flux.fromIterable(List.of(vehicle, vehicle2));
    when(vehicleRepository.findAll()).thenReturn(vehicles);

    StepVerifier.create(vehicleService.findAll())
        .assertNext(result -> assertEquals(result, vehicleDto))
        .assertNext(result -> assertEquals(result, vehicleDto2))
        .verifyComplete();

    verify(vehicleRepository).findAll();
    verifyNoMoreInteractions(vehicleRepository);
  }

  @Test
  void save() {
    VehicleDto vehicleDto = VehicleDto.builder().vin(VIN_1).build();
    ArgumentCaptor<Vehicle> vehicleArgumentCaptor = ArgumentCaptor.forClass(Vehicle.class);
    when(vehicleRepository.save(any(Vehicle.class))).thenReturn(Mono.empty());

    StepVerifier.create(vehicleService.save(vehicleDto)).verifyComplete();

    verify(vehicleRepository).save(vehicleArgumentCaptor.capture());
    verifyNoMoreInteractions(vehicleRepository);
  }
}
