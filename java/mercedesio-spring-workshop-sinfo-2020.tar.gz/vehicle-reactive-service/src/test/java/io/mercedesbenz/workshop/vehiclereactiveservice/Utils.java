package io.mercedesbenz.workshop.vehiclereactiveservice;

public class Utils {

  public static final String VIN_1 = "WDD1000000000000001";
  public static final String VIN_2 = "WDD1000000000000002";
  public static final String VIN_3 = "WDD1000000000000003";
  public static final String VIN_4 = "WDD1000000000000004";
}
