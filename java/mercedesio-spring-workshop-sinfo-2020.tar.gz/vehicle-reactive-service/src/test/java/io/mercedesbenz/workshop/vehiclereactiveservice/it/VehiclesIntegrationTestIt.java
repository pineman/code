package io.mercedesbenz.workshop.vehiclereactiveservice.it;

import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_1;
import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_2;
import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_3;
import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_4;
import static io.mercedesbenz.workshop.vehiclereactiveservice.controller.VehicleController.BASE_URL;

import io.mercedesbenz.workshop.vehiclereactiveservice.model.FuelType;
import io.mercedesbenz.workshop.vehiclereactiveservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclereactiveservice.repository.VehicleRepository;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto.VehicleDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@ActiveProfiles("it")
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
public class VehiclesIntegrationTestIt {

  @Autowired private WebTestClient webTestClient;

  @Autowired private VehicleRepository vehicleRepository;

  @BeforeEach
  public void setUp() {
    vehicleRepository.save(Vehicle.builder().vin(VIN_1).build()).block();
    vehicleRepository.save(Vehicle.builder().vin(VIN_2).build()).block();
  }

  @AfterEach
  public void tearDown() {
    vehicleRepository.deleteAll().block();
  }

  @Test
  public void findByVin_vinExists_success() {
    webTestClient
        .get()
        .uri(BASE_URL + "/{vin}", VIN_1)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("$.vin")
        .isEqualTo(VIN_1);
  }

  @Test
  public void findByVin_vinNotFound_error() {
    webTestClient
        .get()
        .uri(BASE_URL + "/{vin}", VIN_3)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  public void findAll() {
    webTestClient
        .get()
        .uri(BASE_URL)
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(VehicleDto.class)
        .contains(VehicleDto.builder().vin(VIN_1).build())
        .contains(VehicleDto.builder().vin(VIN_2).build())
        .doesNotContain(VehicleDto.builder().vin(VIN_3).build());
  }

  @Test
  void create() {
    webTestClient
        .post()
        .uri(BASE_URL)
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(VehicleDto.builder().vin(VIN_4).brand("Mercedes-Benz").model("C").fuelType(FuelType.ELECTRIC).kw(200).build())
        .exchange()
        .expectStatus()
        .isCreated();
  }
}
