package io.mercedesbenz.workshop.vehiclereactiveservice.controller;

import static io.mercedesbenz.workshop.vehiclereactiveservice.Utils.VIN_1;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclereactiveservice.service.VehicleService;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class VehicleControllerTest {

  private VehicleController vehicleController;

  @Mock private VehicleService vehicleService;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.initMocks(this);
    vehicleController = new VehicleController(vehicleService);
  }

  @Test
  void findByVin() {
    VehicleDto vehicleDto = VehicleDto.builder().vin(VIN_1).build();
    when(vehicleService.findByVin(VIN_1)).thenReturn(Mono.just(vehicleDto));

    StepVerifier.create(vehicleController.findByVin(VIN_1))
        .assertNext(result -> assertEquals(result, vehicleDto))
        .verifyComplete();

    verify(vehicleService).findByVin(VIN_1);
    verifyNoMoreInteractions(vehicleService);
  }

  @Test
  void findAll() {
    VehicleDto vehicle = VehicleDto.builder().vin(VIN_1).build();
    Flux<VehicleDto> vehicles = Flux.fromIterable(List.of(vehicle));
    when(vehicleService.findAll()).thenReturn(vehicles);

    StepVerifier.create(vehicleController.findAll())
        .assertNext(result -> assertEquals(result, vehicle))
        .verifyComplete();

    verify(vehicleService).findAll();
    verifyNoMoreInteractions(vehicleService);
  }

  @Test
  void create() {
    VehicleDto vehicle = VehicleDto.builder().vin(VIN_1).build();
    when(vehicleService.save(vehicle)).thenReturn(Mono.empty());
    ArgumentCaptor<VehicleDto> vehicleArgumentCaptor = ArgumentCaptor.forClass(VehicleDto.class);

    StepVerifier.create(vehicleController.create(vehicle)).verifyComplete();

    verify(vehicleService).save(vehicleArgumentCaptor.capture());
    verifyNoMoreInteractions(vehicleService);
  }
}
