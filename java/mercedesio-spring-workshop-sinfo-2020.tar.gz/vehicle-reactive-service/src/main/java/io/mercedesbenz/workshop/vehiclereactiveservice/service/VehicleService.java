package io.mercedesbenz.workshop.vehiclereactiveservice.service;

import io.mercedesbenz.workshop.vehiclereactiveservice.repository.VehicleRepository;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto.VehicleDto;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.exception.VehicleNotFoundException;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.mapper.VehicleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class VehicleService {

  private final VehicleRepository vehicleRepository;

  @Autowired
  public VehicleService(VehicleRepository vehicleRepository) {
    this.vehicleRepository = vehicleRepository;
  }

  /**
   * A Reactive Stream that emits 0 to N elements, and then completes
   *
   * @return All existing Vehicles.
   */
  public Flux<VehicleDto> findAll() {
    return vehicleRepository.findAll().map(VehicleMapper.INSTANCE::map);
  }

  /**
   * A Reactive Stream with that completes by emitting an 0 or one element.
   *
   * @param vin The identifier of the Vehicle.
   * @return The Vehicle found for the given vin.
   * @throws VehicleNotFoundException when the given vin does not exist.
   */
  public Mono<VehicleDto> findByVin(String vin) {
    return vehicleRepository
        .findById(vin)
        .map(VehicleMapper.INSTANCE::map)
        .switchIfEmpty(Mono.error(new VehicleNotFoundException(vin)));
  }

  /**
   * Saves a given entity. Return a {@code Mono<Void>} which only replays complete and error signals
   * from this {@link Mono}.
   *
   * @param vehicleDto the entity to save.
   * @return a {@link Mono} ignoring its payload (actively dropping)
   */
  public Mono<Void> save(VehicleDto vehicleDto) {
    return vehicleRepository.save(VehicleMapper.INSTANCE.map(vehicleDto));
  }
}
