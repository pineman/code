package io.mercedesbenz.workshop.vehiclereactiveservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleReactiveServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(VehicleReactiveServiceApplication.class, args);
  }
}
