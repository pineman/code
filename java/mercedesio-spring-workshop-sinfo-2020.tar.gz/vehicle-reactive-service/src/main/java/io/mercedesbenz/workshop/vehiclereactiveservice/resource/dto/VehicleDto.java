package io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto;

import io.mercedesbenz.workshop.vehiclereactiveservice.model.FuelType;
import java.io.Serializable;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class VehicleDto implements Serializable {

  @NotNull private String vin;
  private String brand;
  private String model;
  private FuelType fuelType;
  private int kw;
}
