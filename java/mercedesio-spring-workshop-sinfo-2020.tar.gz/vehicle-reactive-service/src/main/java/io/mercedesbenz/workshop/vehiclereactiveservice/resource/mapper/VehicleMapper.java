package io.mercedesbenz.workshop.vehiclereactiveservice.resource.mapper;

import io.mercedesbenz.workshop.vehiclereactiveservice.model.Vehicle;
import io.mercedesbenz.workshop.vehiclereactiveservice.resource.dto.VehicleDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.reactivestreams.Publisher;

@Mapper
public interface VehicleMapper {

  VehicleMapper INSTANCE = Mappers.getMapper(VehicleMapper.class);

  /**
   * Map all {@link Vehicle} fields to {@link VehicleDto} fields.
   *
   * @param vehicle The vehicle to map.
   * @return The mapped vehicle.
   */
  VehicleDto map(Vehicle vehicle);

  /**
   * Map all {@link VehicleDto} fields to {@link Vehicle} fields.
   *
   * @param vehicleDto The vehicle to map.
   * @return The mapped vehicle.
   */
  Vehicle map(VehicleDto vehicleDto);
}
