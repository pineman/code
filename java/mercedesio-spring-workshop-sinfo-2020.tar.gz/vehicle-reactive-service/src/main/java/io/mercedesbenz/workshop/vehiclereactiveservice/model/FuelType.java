package io.mercedesbenz.workshop.vehiclereactiveservice.model;

public enum FuelType {
  DIESEL,
  GASOLINE,
  ELECTRIC,
  HYBRID
}
