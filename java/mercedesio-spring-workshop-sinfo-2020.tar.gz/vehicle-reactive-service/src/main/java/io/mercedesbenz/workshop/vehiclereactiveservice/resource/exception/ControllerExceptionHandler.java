package io.mercedesbenz.workshop.vehiclereactiveservice.resource.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class ControllerExceptionHandler {

  @ExceptionHandler({VehicleNotFoundException.class})
  @ResponseStatus(HttpStatus.NOT_FOUND)
  public String notFoundExceptionHandler(VehicleNotFoundException ex) {
    return handle(ex);
  }

  @ExceptionHandler({Exception.class})
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public String serverExceptionHandler(Exception ex) {
    return handle(ex);
  }

  private String handle(Exception ex) {
    log.error(ex.getMessage());
    return ex.getMessage();
  }
}
