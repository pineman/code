package io.mercedesbenz.workshop.vehiclereactiveservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Document
public class Vehicle {

  @Id private String vin;
  private String brand;
  private String model;
  private String fuelType;
  private int kw;
}
