package io.mercedesbenz.workshop.vehiclereactiveservice.config;

import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import io.mercedesbenz.workshop.vehiclereactiveservice.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractReactiveMongoConfiguration;
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories;

@Configuration
@EnableReactiveMongoRepositories(basePackageClasses = VehicleRepository.class)
public class VehicleReactiveServiceConfig extends AbstractReactiveMongoConfiguration {

  @Value("${database}")
  private String database;

  @Override
  protected String getDatabaseName() {
    return database;
  }

  @Override
  public MongoClient reactiveMongoClient() {
    return MongoClients.create();
  }
}
