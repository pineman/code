package io.mercedesbenz.workshop.vehiclereactiveservice.resource.exception;

public class VehicleNotFoundException extends RuntimeException {

  public VehicleNotFoundException(String vin) {
    super(String.format("Vehicle with vin \"%s\" could not be found.", vin));
  }
}
