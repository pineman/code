package io.mercedesbenz.workshop.vehiclereactiveservice.repository;

import io.mercedesbenz.workshop.vehiclereactiveservice.model.Vehicle;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

/**
 * Repository to interact with external data sources for CRUD operations on {@link Vehicle}
 * resource.
 */
public interface VehicleRepository extends ReactiveCrudRepository<Vehicle, String> {}
