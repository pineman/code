#!/usr/bin/bash
sudo chmod +x asd.py
sudo apt-get install python3 python3-tk
sudo apt-get install mpg123