#!/usr/bin/python3
from tkinter import *
from tkinter import ttk
import os

root = Tk()
# Center the window on the screen
# (screen_width/2) - (window_width/2)
# Same for height
# So lets get em.
# Window will be ("100x50")

screen_width = int(root.winfo_screenwidth())
screen_height = int(root.winfo_screenheight())

window_width = 230
window_height = 20

leftpixel_x = int((screen_width/2) - (window_width/2))
leftpixel_y = int((screen_height/2) - (window_height/2))

root.geometry("230x20+%d+%d" % (leftpixel_x, leftpixel_y))

root.title("Success!")
label = ttk.Label(root, text="My bash installation script worked!").pack()

root.mainloop()

os.chdir(os.path.abspath(os.path.dirname(__file__)))
current_path = os.getcwd()
os.system("mpg123 -f 10000 " + str(current_path) + "/asd.mp3")